import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		dadosPessoais objdadospessoais = new dadosPessoais();
		dadoContato objdadoContato = new dadoContato();
		dadoEndereco objdadoendereco = new dadoEndereco();
		
		
		//infome o nome
		System.out.println("---Seja bem-vindo---");
		System.out.println("Digite seu nome: ");
		objdadospessoais.setNome(scanner.next());
		
		
		//informe sobrenome
		System.out.println("Digite seu Sobrenome: ");
		objdadospessoais.setSobrenome(scanner.next());
		
		//Informe a data de nascimento
		System.out.println("Digite a Data de Nascimento assim XX/XX/XXXX: ");
		objdadospessoais.setDataNascimento(scanner.next());

		//Informe o genero
		System.out.println("Digite seu genero: ");
		objdadospessoais.setGenero(scanner.next());
		
		
		//Informe o email
		System.out.println("Digite seu Email");
		objdadoContato.setEmail(scanner.next());
		
		//Informe o Contato
		System.out.println("digite seu telefone assim (XX)XXXXX-XXX-X");
        objdadoContato.setTelefone(scanner.next());
        
        //Informe o cep
        System.out.println("Digite o seu cep: ");
        objdadoendereco.setCep(scanner.next());
        
        //Informe o logradouro
        System.out.println("Digite o seu Logradouro: ");
        objdadoendereco.setLogradouro(scanner.next());
        
        //Informe o numeroI
        System.out.println("Digite o seu numero: ");
        objdadoendereco.setNumero(scanner.next());
        
        //Informe o Bairro
        System.out.println("Digite o seu Bairro: ");
        objdadoendereco.setBairro(scanner.next());
        
        //Informe a cidade
        System.out.println("Digite o sua cidade: ");
        objdadoendereco.setCidade(scanner.next());
        
        //Informe o estado
        System.out.println("Digite o seu estado: ");
        objdadoendereco.setEstado(scanner.next());
        
        //Agradecimento
        System.out.println("--Obrigado pela aten��o--");
        
        //Fim da pagina
	}
}